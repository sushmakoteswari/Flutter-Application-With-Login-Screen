import 'package:flutter/painting.dart';

class Palette {
  static const Color loginPageColor = Color(0XFFFF1744);
  static const Color homePageColor = Color(0xFFA1A237E);
}
